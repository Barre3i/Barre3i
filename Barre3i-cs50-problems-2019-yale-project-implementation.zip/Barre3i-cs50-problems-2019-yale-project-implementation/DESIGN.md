    Our goal in the project was to create March Mandess brackets that used FiveThirtyEight probabilities to maximize the expected number of points of the bracket. While producing our own probabilities
was (1) superfluous to data provided by FiveThirtyEight and (2) likely unfeasible for us, FiveThirtyEight (nor any other site to our knowledge) currently provides no method of turning those
probabilities into an actual bracket. This is both surprisingly difficult (its not immediately clear how probabilities convert into expected points) and highly dependent on the user's scoring
system. Some sites, such as ESPN use a very basic scoring system (a certain number of points for each correctly picked game that depends only on round, not seed). Other sites, scuch as CBS,
multiply correct picks by the seed of the winning team, rewarding upsets. Our goal was to write an algorithm that could produce a bracket maximizing expected value given a customized scoring
system.
    First, we import teams and probabilities from FiveThirtyEight. We were able to download FiveThirtyEight's csvs from the internet, but the data was messy and needed to be edited
and re-arranged into more usable data. The function sort() does this in our file helpers.py.
    Next, we calculate two statistics per round (12 total) for each team. First, we calculate the expected value of picking each team to win each game, which we do by simply multiplying
the number of points a correct pick would yield (dependent on scoring system) times the probability. Once we have the expected values by round for each team, we can calculate the "sum
values" by round for each team, which consists of summing the team's expected value for each game up to and including the round in question. We upload both expected values and summed values
for each round and team into a SQL database expected_values.We also want to keep track of which teams are elligible to play in each game. Because of the bracket-format of the tournament,
teams are only eligible to play on specific game tracks (for example, a team in the East region can not possibly play in the West semifinal). We denote the games of the tournament as
100-131 for round of 64 games, 200-215 for round of 32 games, 300-307 for sweet 16 games and so on. After determining which teams are eligible to play in which games, we then upload this
to a SQL database games. These steps are implement in the function upload() in helpers.py.
     Before actually creating our first bracket, we first modify our expected values depending on risk, the motivation for which is discussed later. In the function create() we finally
build the first iteration of our bracket. While it's tempting to simply compare the expected values in each game and pick the winner, this method ultimately isn't very successful. As an
illustration, consider a potential 2019 matchup between Duke and Virginia tech in the sweet 16. Duke, a 1 seed, is given a 72% chance to win. Virginia Tech, a 4 seed, is given a 19%
chance to win. If we simply look at expected values, under many scoring systems (e.g. multiply seed by game weight) Virginia Tech would be the winner. However, by choosing Duke to win
instead, we progress them further in the tournament, where they end up becoming the team generates the most expected value, more than making up for any expected value you lose by choosing
them to defeat Virginia Tech. To prevent this type of error from happening, we instead look at sum values. We start at the national championship and choose the team that generates the
highest sum value for the national championship. But, choosing this team to win the tournament implies that they must also win all their games leading up to the final game, so we fill in this team
as the winner of those games as well. We then work inside-out, progressively working from the end of the tournament to the beginning. If there is already a predetermined winner of a given
game, we leave it be. However, if the game currently has no winner, we pick the team with the highest sum value for that round and adjust accordingly. We do this until we have a complete
bracket.
    After running this algorithm on historical data, while we noticed it was performing better than simply choosing the team wtih the higher expected value, we still saw room for improvement.
Specifically, we realized that there is a downside to filling out the bracket using sum values– teams with exceptionally high expected values in early games artifically inflate their
late-game summed value, causing us to pick them when this is detrimental to maximizing expected value. To fix this, we consider games whose winner loses their next game. Looking at the two
teams playing in each such game, we simply choose the team with the higher expected value for that round as the winner (and by only looking at games whose winner loses their next game,
we no longer risk running into the error described in the last paragraph). Doing so changes the winner for some, but not all of the games in question and improves our bracket by fixing those
games. This process is implemented in update(). However, it is possible that by altering the bracket, we create new matchups with expected value mistakes. To address this, we decided to run
update() recursively, ending only when the outputed bracket is identical to the inputed bracket, meaning there are no more games with obvious errors in expected value calculations. This
process of creating a bracket and then updating it recursively generates our bracket.
    Next, we actually calculate the expected value of our bracket so the user can test our algorithms performance vs other brackets. To do so, we first need to de-adjust our expected value
calculations for risk and then simply calculate expected value by multiplying value times probability for each game. This is done in the function expectedvalue(). Finally, since we are
using historical data (2020 brackets are yet to be released), we can see how our bracket performed given the actual results of the tournament. This is done in the function hindsight().
Thus, our algorithm ultimately produces three things: a bracket maximizing expected value, the expected value of that bracket, and how many points that bracket would have actually scored.
    After evaluating the brackets our algorithm was producing to see how we were doing, we noticed that while our algorithm seemed to be maximizing expected value reasonably well, this often
led to really risky brackets. For example, in 2017, our bracket recommended a final game of Saint Mary's vs. Wichita State (a 7 seed and a 10 seed). This appears to in fact be the "correct"
solution if we only care about expected values, but most users likely want a far safer bracket. So, we decided to add a feature where the user could customize their risk tolerance designed
to produce safer brackets. We ultimately decided that the most effective way to do this was to simply edit our expected and sum values, as these values fundamentally determine how brackets
ar produced. While altering such values technically desociates these values from what they technically mean, it seemed to be the most effective way to manipulate the bracket in the manner
we wanted (and we readjust these values before calculating expectedvalue and hindsight). To adjust for risk, we multiply each team's statistics by a risk multiplier, which is a function of seed
and round: teams with low seeds get a risk multiplier greater than 1 (the lower the seed, the greater the risk multiplier), while teams high seeds get a risk multipler below one (the higher
the seed, the lower the risk multiplier). Additionally, the risk multiplier increases in magnitude (moves further from 1) in later games, as these games have a greater impact on overall
standard deviation.
    Having successfully created a bracket that maximizes expected values under certain parameters (scoring system an risk tolerance), the only thing left to do was to "clean up for ourselves"
by emptying the tables we had created. We originally did this after creating our bracket, but this was producing a weird sort of error. Because the SQL commands take a long time to run, our
Python program is rather slow. If we run it all at once, the chrome webpage takes over a mnute to load. We believe that this was somehow causing chrome to attempt to reload the page,
restarting our code and causing errors. To fix this, we moved the delete function to happen before we produce a bracket rather than after. This way, we split the time our program takes
to run into two separate loading pages, avoiding the aforementioned error while still clearing out the database before we use them.
    To display our algorithm, we devloped an HTML page that describes (1) background on March Madness (2) Why our algorithm is important/useful (3) basic information about how our
algorithm works and (4) a page to actually build your own bracket. Our final bracket is displayed using a template we found online. The HTML interacts with our algorithm via Flask in a
similar way to Finance and should be reasonably error-proof.