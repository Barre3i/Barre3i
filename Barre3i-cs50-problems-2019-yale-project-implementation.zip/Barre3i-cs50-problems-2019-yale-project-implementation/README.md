User’s Manual for A Better Bracket

The mission of A Better Bracket is to simply help users win their March Madness bracket challenges.
In order to use our project, first make sure that you’re in the right directory and then run flask run — doing so should provide you with a link to our website.
Click on the link and you will see our homepage explaining our project.

Michael and I (project creators) tried to be very clear about what our project does and assumed that our user has limited knowledge of how March Madness works.
Thus, we created separate html pages precisely explaining what March Madness is, what our project accomplishes, and how our algorithm works.
After reading these html pages, any user should feel comfortable building his or her own bracket.

In order to build a bracket, click the Build link at the top of the page.
Next, enter the year you want to build a bracket for.
Then, you will be asked to enter scoring weights for each of the rounds (must enter an integer greater than or equal to 0).
You will also be asked for a scoring type and risk tolerance. If any of these fields are left blank, our algorithm will use the default values of
Year: 2019, Scoring Type: Multiply seed by round weight, Risk Tolerance: Neutral, Scoring Weights: 1 for Round of 64, 5 for Round of 32, 20 for Sweet 16, 30 for Elite 8, 75 for Final Four, and 150 for National Championship.

Once you submit, you should see your customized bracket along with your expected bracket score and actual score based on the tournament results.
