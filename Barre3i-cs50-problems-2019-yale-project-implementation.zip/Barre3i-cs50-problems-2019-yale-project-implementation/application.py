import os

import csv
from cs50 import SQL
from helpers import sort, upload, create, update, calculate, delete, hindsight
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session

# Configure application
app = Flask(__name__)

@app.route("/")
def starter():
    # send to home page
    return render_template("starter.html")

@app.route("/learn.html")
def learn():
    # send to learn
    return render_template("learn.html")

@app.route("/mission.html")
def mission():
    # send to mission
    return render_template("mission.html")

@app.route("/howItWorks.html")
def howItWorks():
    # send to how it works
    return render_template("howItWorks.html")

@app.route("/year.html", methods = ["GET", "POST"])
def year():
    if request.method == "GET":
        # send to year
        return render_template("year.html")
    if request.method == "POST":
        #submit to year
        year = request.form.get("year")
        # if blank set year = 2019
        if not year:
            year = "2019"
        # assign gender
        gender = request.form.get("gender")
        if not gender:
            gender = "mens"
        # create teams
        dictionary = sort(year, gender)
        db = SQL("sqlite:///tables.db")
        #clean database before use
        delete(db)
        #send to build
        return render_template("build.html", year = year, gender = gender)

@app.route("/build.html", methods=["GET", "POST"])
def build():
    if request.method == "GET":
        # send to build
        return render_template("build.html")
    if request.method == "POST":
        #set databse
        db = SQL("sqlite:///tables.db")
        #get year, weightingtype, and weightings from HTML
        year = request.form.get("year")
        gender = request.form.get("gender")
        weightingtype = request.form.get("scoringtype")
        #if let empty, set to multiply
        if not weightingtype:
            weightingtype = "M"
        weightings = []
        #if any field is empty, set weightings = [1, 5, 20, 30, 75, 150]
        for i in range(1,7):
            string = "round" + str(i)
            try:
                integer = int(request.get(string))
                weightings.append(integer)
            except:
                test = 0
        if len(weightings) != 6:
            weightings = [1, 5, 20, 30, 75, 150]
        # get risk from form
        risk = request.form.get("risk")
        if risk:
            if risk[0] == "-":
                risk = -1 * int(risk[1])
            else:
                risk = int(risk[0])
        else:
            risk = 0
        # create our dictionary
        dictionary = sort(year, gender)
        print(dictionary)
        # upload to SQL
        uploaded = upload(year, dictionary, weightings, weightingtype, db)
        # create bracket 1
        created = create(uploaded, risk, db)
        # update until steady state is reached
        while True:
            temp = created.copy()
            created = update(created, risk, uploaded, db)
            if temp == created:
                break
        # calculate expected value
        expectedvalue = calculate(created, db)
        # calculate actual vale
        score = hindsight(created, year, gender, weightings, weightingtype)
        # send to finished
        return render_template("finished.html", CREATED = created, year = year, gender = gender, expectedvalue = expectedvalue, score = score)

