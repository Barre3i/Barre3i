import csv
from cs50 import SQL
import math

def sort(YEAR, GENDER):
    placeholder = {}
    # find right dates
    with open("probabilities" + YEAR + ".csv") as csv_file:
        if YEAR == "2019":
            date = "2019-03-17"
        if YEAR == "2018":
            date = "2018-03-12"
        if YEAR == "2017":
            date = "2017-03-12"
        if YEAR == "2016":
            date = "2016-03-14"
        # read into dict
        csv_dict = csv.DictReader(csv_file)
        # make new dict with correct data
        for row in csv_dict:
            if row["forecast_date"] == date and row["gender"] == GENDER:
                p = {row["team_name"]: [row["team_region"], row["team_seed"], row["rd2_win"], row["rd3_win"], row["rd4_win"], row["rd5_win"], row["rd6_win"], row["rd7_win"]]}
                for i in range(2, 8):
                    p[row["team_name"]][i] = float(p[row["team_name"]][i])
                placeholder.update(p)
    dictionary = {}
    # adjust for play-in games
    for team in placeholder:
        if len(placeholder[team][1]) > 2:
            if placeholder[team][1].endswith("a"):
                for finder in placeholder:
                    if placeholder[team][0] == placeholder[finder][0] and team != finder and placeholder[team][1] == placeholder[finder][1][:-1] + "a":
                        for i in range(2,8):
                            placeholder[team][i] = placeholder[team][i] + placeholder[finder][i]
                        dictionary.update({team + "/" + finder: placeholder[team]})
        else:
            dictionary.update({team: placeholder[team]})
    # turn seeds into ints
    for team in dictionary:
        try:
            dictionary[team][1] = int(dictionary[team][1])
        except:
            dictionary[team][1] = int(dictionary[team][1][:-1])
    return dictionary

def upload(YEAR, DICTIONARY, WEIGHTINGS, WEIGHTINGTYPE, db):
    for team in DICTIONARY:
        a = []
        b = []
        # calculate expected values
        for i in range(6):
            if WEIGHTINGTYPE == "M":
                a.append(WEIGHTINGS[i] * DICTIONARY[team][1] * DICTIONARY[team][i + 2])
            if WEIGHTINGTYPE == "A":
                a.append(WEIGHTINGS[i] * DICTIONARY[team][i + 2] + DICTIONARY[team][1])
            if WEIGHTINGTYPE == "L":
                a.append(WEIGHTINGS[i] * DICTIONARY[team][i + 2] * math.log(DICTIONARY[team][1] + 1))
            if WEIGHTINGTYPE == "N":
                a.append(WEIGHTINGS[i] * DICTIONARY[team][i + 2])
        # calculate summed values
        for i in range(1,7):
            x = 0
            for j in range(i):
                x = x + a[j - 1]
            b.append(x)
        # insert into SQL database
        db.execute("INSERT INTO expected_values VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    team, DICTIONARY[team][1], a[0], b[0], a[1], b[1], a[2], b[2], a[3], b[3], a[4], b[4], a[5], b[5])
        # calculate games by region and seed
        round6 = 600
        if DICTIONARY[team][0] == "East" or DICTIONARY[team][0] == "Greensboro" or (DICTIONARY[team][0] == "Albany" and YEAR == "2018") or DICTIONARY[team][0] == "Bridgeport":
            round5 = 500
            round4 = 400
            round3 = 300
            round2 = 200
            round1 = 100
        elif DICTIONARY[team][0] == "West" or DICTIONARY[team][0] == "Portland" or DICTIONARY[team][0] == "Spokane" or DICTIONARY[team][0] == "Oklahoma City" or DICTIONARY[team][0] == "Dallas":
            round5 = 500
            round4 = 401
            round3 = 302
            round2 = 204
            round1 = 108
        elif DICTIONARY[team][0] == "South" or  DICTIONARY[team][0] == "Chicago" or DICTIONARY[team][0] == "Kansas City" or (DICTIONARY[team][0] == "Lexington" and YEAR == "2017") or DICTIONARY[team][0] == "Sioux Falls":
            round5 = 501
            round4 = 402
            round3 = 304
            round2 = 208
            round1 = 116
        elif DICTIONARY[team][0] == "Midwest" or (DICTIONARY[team][0] == "Albany" and YEAR == "2019") or (DICTIONARY[team][0] == "Lexington" and YEAR != "2017") or DICTIONARY[team][0] == "Stockton":
            round5 = 501
            round4 = 403
            round3 = 306
            round2 = 212
            round1 = 124
        if DICTIONARY[team][1] == 8 or DICTIONARY[team][1] == 9:
            round1 += 1
        if DICTIONARY[team][1] == 5 or DICTIONARY[team][1] == 12:
            round1 += 2
            round2 += 1
        if DICTIONARY[team][1] == 4 or DICTIONARY[team][1] == 13:
            round1 += 3
            round2 += 1
        if DICTIONARY[team][1] == 6 or DICTIONARY[team][1] == 11:
            round1 += 4
            round2 += 2
            round3 += 1
        if DICTIONARY[team][1] == 3 or DICTIONARY[team][1] == 14:
            round1 += 5
            round2 += 2
            round3 += 1
        if DICTIONARY[team][1] == 7 or DICTIONARY[team][1] == 10:
            round1 += 6
            round2 += 3
            round3 += 1
        if DICTIONARY[team][1] == 2 or DICTIONARY[team][1] == 15:
            round1 += 7
            round2 += 3
            round3 += 1
        # insert into games database
        db.execute("INSERT INTO games (team, game1, game2, game3, game4, game5, game6) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    team, round1, round2, round3, round4, round5, round6)
    return DICTIONARY


def create(DICTIONARY, RISK, db):
    # set winners sizes
    winners = [[], [], [], [], ["NULL", "NULL", "NULL", "NULL"], ["NULL", "NULL"], ["NULL"]]
    # set winners[0]
    for i in range(100, 132):
            teams = db.execute("SELECT team FROM games WHERE game1 = ?", i)
            winners[0].append(teams[0]["team"])
            winners[0].append(teams[1]["team"])
    for i in range(32):
        winners[1].append("NULL")
    for i in range(16):
        winners[2].append("NULL")
    for i in range(8):
        winners[3].append("NULL")
    # calculate risk for each team
    for key in DICTIONARY:
        riskf = (8.5 - db.execute("SELECT seed FROM expected_values WHERE team = ?", key)[0]["seed"]) * .01333 * RISK + 1
        # adjust values in database
        db.execute("UPDATE expected_values SET round1e = round1e * ?, round1s = round1s * ?, round2e = round2e * ?, round2s = round2s * ?, round3e = round3e * ?, \
                    round3s = round3s * ?, round4e = round4e * ?, round4s = round4s * ?, round5e = round5e * ?, round5s = round5s * ?, round6e = round6e * ?, \
                    round6s = round6s * ? WHERE team = ?",
                    riskf / 3, riskf / 3, riskf * 2 / 3, riskf * 2 / 3, riskf, riskf, riskf * 4 / 3, riskf * 4 / 3,
                    riskf * 5 / 3, riskf * 5 / 3, riskf * 2, riskf * 2, key)
    k = db.execute("SELECT team, game1, game2, game3, game4, game5 FROM games WHERE team = (SELECT team FROM expected_values WHERE round6s = (SELECT \
                    MAX(round6s) from expected_values WHERE team IN (SELECT team FROM games WHERE game6 = ?)))", 600)
    # find winners[6] and update accordingly
    winners[6][0] = k[0]["team"]
    for i in range(5, 0, -1):
        game = "game" + str(i)
        winners[i][k[0][game] - 100 * i] = k[0]["team"]
    # find winners[5] and update accordingly
    for game_num in range(500, 502):
        if winners[5][game_num - 500] == "NULL":
            k = db.execute("SELECT team, game1, game2, game3, game4 FROM games WHERE team = (SELECT team FROM expected_values WHERE round5s = (SELECT \
                            MAX(round5s) from expected_values WHERE team IN (SELECT team FROM games WHERE game5 = ?)))", game_num)
            winners[5][game_num - 500] = k[0]["team"]
            for i in range (4, 0, -1):
                game = "game" + str(i)
                if winners[i][k[0][game] - 100 * i] == "NULL":
                    winners[i][k[0][game] - 100 * i] = k[0]["team"]
    # find winners[4] and update accordingly
    for game_num in range(400, 404):
        if winners[4][game_num - 400] == "NULL":
            k = db.execute("SELECT team, game1, game2, game3 FROM games WHERE team = (SELECT team FROM expected_values WHERE round4s = (SELECT \
                            MAX(round4s) from expected_values WHERE team IN (SELECT team FROM games WHERE game4 = ?)))", game_num)
            winners[4][game_num - 400] = k[0]["team"]
            for i in range (3, 0, -1):
                game = "game" + str(i)
                if winners[i][k[0][game] - 100 * i] == "NULL":
                    winners[i][k[0][game] - 100 * i] = k[0]["team"]
    # find winners[3] and update accordingly
    for game_num in range(300, 308):
        if winners[3][game_num - 300] == "NULL":
            k = db.execute("SELECT team, game1, game2 FROM games WHERE team = (SELECT team FROM expected_values WHERE round3s = (SELECT \
                            MAX(round3s) from expected_values WHERE team IN (SELECT team FROM games WHERE game3 = ?)))", game_num)
            winners[3][game_num - 300] = k[0]["team"]
            if winners[2][k[0]["game2"] - 200] == "NULL":
                winners[2][k[0]["game2"] - 200] = k[0]["team"]
            if winners[1][k[0]["game1"] - 100] == "NULL":
                winners[1][k[0]["game1"] - 100] = k[0]["team"]
    # find winners[2] and update accordingly
    for game_num in range(200, 216):
        if winners[2][game_num - 200] == "NULL":
            k = db.execute("SELECT team, game1 FROM games WHERE team = (SELECT team FROM expected_values WHERE round2s = (SELECT \
                            MAX(round2s) from expected_values WHERE team IN (SELECT team FROM games WHERE game2 = ?)))", game_num)
            winners[2][game_num - 200] = k[0]["team"]
            if winners[1][k[0]["game1"] - 100] == "NULL":
                winners[1][k[0]["game1"] - 100] = k[0]["team"]
    # find winners[1] and update accordingly
    for game_num in range(100, 132):
        if winners[1][game_num - 100] == "NULL":
            team1 = db.execute("SELECT team, round1e FROM expected_values WHERE team IN (SELECT team FROM games WHERE game1 = ?)", game_num)[0]
            team2 = db.execute("SELECT team, round1e FROM expected_values WHERE team IN (SELECT team FROM games WHERE game1 = ?)", game_num)[1]
            if team1["round1e"] > team2["round1e"]:
                winners[1][game_num -100] = team1["team"]
            else:
                winners[1][game_num - 100] = team2["team"]
    return winners

def update(WINNERS, RISK, DICTIONARY, db):
    #copy winners
    alpha = WINNERS
    for team in WINNERS[2]:
        # find correct games
        if team not in WINNERS[3]:
            index = WINNERS[2].index(team)
            # find teams playing in games
            team1 = WINNERS[1][index * 2]
            team2 = WINNERS[1][index * 2 + 1]
            p1 = db.execute("SELECT round2e FROM expected_values WHERE team = ?", team1)[0]
            p2 = db.execute("SELECT round2e FROM expected_values WHERE team = ?", team2)[0]
            # choose team with higher expected value
            if p1["round2e"] > p2["round2e"]:
                alpha[2][index] = team1
            else:
                alpha[2][index] = team2
    for team in WINNERS[3]:
        # find correct games
        if team not in WINNERS[4]:
            index = WINNERS[3].index(team)
            # find teams playing in games
            team1 = WINNERS[2][index * 2]
            team2 = WINNERS[2][index * 2 + 1]
            p1 = db.execute("SELECT round3e FROM expected_values WHERE team = ?", team1)[0]
            p2 = db.execute("SELECT round3e FROM expected_values WHERE team = ?", team2)[0]
            # choose team with higher expected value
            if p1["round3e"] > p2["round3e"]:
                alpha[3][index] = team1
            else:
                alpha[3][index] = team2
    for team in WINNERS[4]:
        # find correct games
        if team not in WINNERS[5]:
            index = WINNERS[4].index(team)
            # find teams playing in games
            team1 = WINNERS[3][index * 2]
            team2 = WINNERS[3][index * 2 + 1]
            p1 = db.execute("SELECT round4e FROM expected_values WHERE team = ?", team1)[0]
            p2 = db.execute("SELECT round4e FROM expected_values WHERE team = ?", team2)[0]
            # choose team with higher expected value
            if p1["round4e"] > p2["round4e"]:
                alpha[4][index] = team1
            else:
                alpha[4][index] = team2
    for team in WINNERS[5]:
        # find correct games
        if team not in WINNERS[6]:
            index = WINNERS[5].index(team)
            # find teams playing in games
            team1 = WINNERS[4][index * 2]
            team2 = WINNERS[4][index * 2 + 1]
            p1 = db.execute("SELECT round5e FROM expected_values WHERE team = ?", team1)[0]
            p2 = db.execute("SELECT round5e FROM expected_values WHERE team = ?", team2)[0]
            # choose team with higher expected value
            if p1["round5e"] > p2["round5e"]:
                alpha[5][index] = team1
            else:
                alpha[5][index] = team2
    p1 = db.execute("SELECT round6e FROM expected_values WHERE team = ?", WINNERS[5][0])[0]
    p2 = db.execute("SELECT round6e FROM expected_values WHERE team = ?", WINNERS[5][1])[0]
    # choose team with higher expected value
    if p1["round6e"] > p2["round6e"]:
        alpha[6][0] = WINNERS[5][0]
    else:
        alpha[6][0] = WINNERS[5][1]
    # readjust for risk
    for key in DICTIONARY:
        riskf = 1 + RISK * (8.5 - db.execute("SELECT seed FROM expected_values WHERE team = ?", key)[0]["seed"]) * .01333
        db.execute("UPDATE expected_values SET round1e = round1e / ?, round1s = round1s / ?, round2e = round2e / ?, round2s = round2s / ?, round3e = round3e / ?, \
                    round3s = round3s / ?, round4e = round4e / ?, round4s = round4s / ?, round5e = round5e / ?, round5s = round5s / ?, round6e = round6e / ?, \
                    round6s = round6s / ? WHERE team = ?",
                    (riskf / 3), (riskf / 3), (riskf * 2 / 3), (riskf * 2 / 3), riskf, riskf, (riskf * 4 / 3), (riskf * 4 /3), (riskf * 5 / 3), (riskf * 5 / 3), 2 * riskf, 2 * riskf, key)
    return alpha

def calculate(CREATED, db):
    # calculate expectedvalue
    expectedvalue = 0
    for team in CREATED[1]:
        expectedvalue = expectedvalue + db.execute("SELECT round1e FROM expected_values WHERE team = ?", team)[0]["round1e"]
    for team in CREATED[2]:
        expectedvalue = expectedvalue + db.execute("SELECT round2e FROM expected_values WHERE team = ?", team)[0]["round2e"]
    for team in CREATED[3]:
        expectedvalue = expectedvalue + db.execute("SELECT round3e FROM expected_values WHERE team = ?", team)[0]["round3e"]
    for team in CREATED[4]:
        expectedvalue = expectedvalue + db.execute("SELECT round4e FROM expected_values WHERE team = ?", team)[0]["round4e"]
    for team in CREATED[5]:
        expectedvalue = expectedvalue + db.execute("SELECT round5e FROM expected_values WHERE team = ?", team)[0]["round5e"]
    expectedvalue = expectedvalue + db.execute("SELECT round6e FROM expected_values WHERE team = ?", CREATED[5][0])[0]["round6e"]
    return expectedvalue

def delete(db):
    # clear databases
    teams = db.execute("SELECT team FROM games")
    for i in range(len(teams)):
        team = teams[i]["team"]
        db.execute("DELETE FROM games WHERE team = ?", team)
        db.execute("DELETE FROM expected_values WHERE team = ?", team)
    return

def hindsight(CREATED, YEAR, GENDER, WEIGHTINGS, WEIGHTINGTYPE):
    placeholder = {}
    with open("probabilities" + str(YEAR) + ".csv") as csv_file:
        # set correct dates
        if GENDER == "mens":
            if YEAR == "2019":
                date = "2019-04-06"
            if YEAR == "2018":
                date = "2018-03-31"
            if YEAR == "2017":
                date = "2017-04-01"
            if YEAR == "2016":
                date = "2016-04-02"
        else:
            if YEAR == "2019":
                date = "2019-04-05"
            if YEAR == "2018":
                date = "2018-03-30"
            if YEAR == "2017":
                date = "2017-03-31"
            if YEAR == "2016":
                date = "2016-04-03"
        # read into dictionary
        csv_key = csv.DictReader(csv_file)
        # select data we want
        for row in csv_key:
            if row["forecast_date"] == date and row["gender"] == GENDER:
                p = {row["team_name"]: [row["team_region"], row["team_seed"], row["rd2_win"], row["rd3_win"], row["rd4_win"], row["rd5_win"], row["rd6_win"], row["rd7_win"]]}
                for i in range(2, 8):
                    p[row["team_name"]][i] = float(p[row["team_name"]][i])
                placeholder.update(p)
    dictionary = {}
    # adjust for play in games
    for team in placeholder:
        if len(placeholder[team][1]) > 2:
            if placeholder[team][1].endswith("a"):
                for finder in placeholder:
                    if placeholder[team][0] == placeholder[finder][0] and team != finder and placeholder[team][1] == placeholder[finder][1][:-1] + "a":
                        for i in range(2,8):
                            placeholder[team][i] = placeholder[team][i] + placeholder[finder][i]
                        dictionary.update({team + "/" + finder: placeholder[team]})
        else:
            dictionary.update({team: placeholder[team]})
    # convert seeds to ints
    for team in dictionary:
        try:
            dictionary[team][1] = int(dictionary[team][1])
        except:
            dictionary[team][1] = int(dictionary[team][1][:-1])
    # set winner probabilities
    if GENDER == "mens":
        if YEAR == "2019":
            dictionary["Virginia"][7] = 1
            dictionary["Texas Tech"][7] = 0
        if YEAR == "2018":
            dictionary["Villanova"][7] = 1
            dictionary["Michigan"][7] = 0
        if YEAR == "2017":
            dictionary["North Carolina"][7] = 1
            dictionary["Gonzaga"][7] = 0
        if YEAR == "2016":
            dictionary["Villanova"][7] = 1
            dictionary["North Carolina"][7] = 0
    else:
        if YEAR == "2019":
            dictionary["Baylor"][7] = 1
            dictionary["Notre Dame"][7] = 0
        if YEAR == "2018":
            dictionary["Notre Dame"][7] = 1
            dictionary["Mississippi State"][7] = 0
        if YEAR == "2017":
            dictionary["South Carolina"][7] = 1
            dictionary["Mississippi State"][7] = 0
        if YEAR == "2016":
            dictionary["Connecticut"][7] = 1
            dictionary["Syracuse"][7] = 0

    score = 0
    # calculate score
    for i in range(6):
        for team in CREATED[i + 1]:
            if WEIGHTINGTYPE == "M":
                score = score + WEIGHTINGS[i] * dictionary[team][i + 2] * dictionary[team][1]
            if WEIGHTINGTYPE == "A":
                score = score + (WEIGHTINGS[i] + dictionary[team][1]) * dictionary[team][i + 2]
            if WEIGHTINGTYPE == "L":
                score = score + WEIGHTINGS[i] * dictionary[team][i + 2] * math.log(dictionary[team][1] + 1)
            if WEIGHTINGTYPE == "N":
                score = score + WEIGHTINGS[i] * dictionary[team][i + 2]
    return score
